using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DevMiniOS.Areas.MiniModel.Views
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
